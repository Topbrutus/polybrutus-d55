# Polybrutus D54 - immutable source provenance and AI disclosure

**Human scientific author:** Gabriel St-Pierre, independent researcher. **Material AI assistance:** OpenAI ChatGPT (Astra) helped independently coded rational verifiers, scientific manuscript and controlled publication; AI is not a scientific author.

**Exclusive direct parent:** Topbrutus/polybrutus-d53@v0.1.0, peeled Git tag commit \`4bd7435e63ecf58be4ce7940a61e1d6a37d29203\`, DOI 10.5281/zenodo.24430556. The original full scientific ZIP \`prior/d53/frozen_scientific_tag_v0.1.0.zip\` is copied byte-identically: 3102647 bytes, 32 entries, ZIP CRC PASS, SHA256 \`872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698\`, including all earlier original nested archives. The original D53 certificate \`prior/d53/results/certificate_d53.json\` is copied byte-identically, SHA256 \`b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47\`. Both verifiers authenticate original archive SHA, CRC, the original exact certificate and all 1653 old labels.

**Historical documentary caveat:** the original D47 certificate includes an incorrect textual grandparent D46 Git commit, disclosed since D48. Older original bytes are never silently rewritten; D54 independently authenticates the real immediate D53 scientific tag and its original certificate. Some original ZIP text differs from frozen Git blob only in CRLF vs LF line endings; original ZIP stays untouched.

Zenodo metadata will store structured \`isDerivedFrom\` D53 DOI 10.5281/zenodo.24430556, separate references to D53 and D7 10.5281/zenodo.24407952.
**Scientific limits:** This is a constructed synthetic Euclidean squared-distance metric and a separately stipulated dimensionless ideal weighted graph. No measured hertz, physical extra spacetime dimensions, particles, new universal theorem or independent human peer review are claimed.
