# Polybrutus D54 - exact 59-point Euclidean metric and forty-eightfold ideal graph mode

**Human scientific author:** Gabriel St-Pierre, independent researcher. **Material AI assistance:** OpenAI ChatGPT (Astra) materially assisted independent exact programs, writing and controlled publication; AI is not the scientific author.

## Reproducible exact results

- **59** norm-one points and **1711 / 1711** rational unordered labelled squared-distance pairs.
- **1653 / 1653** predecessor D53 labelled squared distances unchanged; **58** new squared distances each exactly **2R²**.
- Rational Gram and centered Gram both PSD of exact rank **54**, establishing minimum affine Euclidean dimension 54 for this one constructed metric; 55 storage coordinates.
- Unit-radius histogram k=4d²/R²: 4:6, 7:2, 8:1680, 9:3, 10:10, 12:6, 13:2, 16:2. Exact sum of all squared distances R=1: **13735/4**.
- A **separately stipulated** ideal scalar-unit-mass complete weighted graph with w_ij=1/d_ij² has Laplacian eigenvalue **59/2 multiplicity 48**, and **29 multiplicity 4** (dimensionless model values, not observed hertz).
- Two mathematically separate exact programs, original full parent ZIP SHA/CRC and byte-identical parent certificate, all preserved labels, and four primary adversarial negative controls verified.

Reproduce (Python 3.12, sympy 1.14.0):

    python -m pip install sympy==1.14.0
    python src/verify_d54.py
    python tests/independent_d54.py
    python src/check_zenodo_metadata.py

Both programs compare the deterministic JSON certificate \`results/certificate_d54.json\`. Continuous integration runs both, verifies certificate determinism, and checks current Zenodo metadata and bibliography.

## Single direct frozen scientific predecessor

[Polybrutus D53 v0.1.0](https://github.com/Topbrutus/polybrutus-d53/tree/v0.1.0), peeled commit \`4bd7435e63ecf58be4ce7940a61e1d6a37d29203\`, DOI [10.5281/zenodo.24430556](https://doi.org/10.5281/zenodo.24430556). Its entire complete original frozen source ZIP (including nested original ancestors) is stored **unchanged** at \`prior/d53/frozen_scientific_tag_v0.1.0.zip\`, SHA-256 \`872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698\`; original D53 certificate SHA-256 \`b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47\` is preserved unchanged.

Zenodo contract: **nine current D54 keywords**, including \`fifty-four\` and \`forty-eightfold\`, **structured isDerivedFrom** to direct predecessor DOI D53 10.5281/zenodo.24430556 and **separate textual references** to D53 and historical D7 DOI 10.5281/zenodo.24407952.

[Specification](SPECIFICATION_D54.md) | [proof](PREUVE_D54.md) | [provenance](PROVENANCE.md) | [bibliography](REFERENCES.md) | [scientific two-page PDF](publication/POLYBRUTUS_54D_NOTE.pdf).

**Scientific limits:** This is a constructed synthetic Euclidean squared-distance metric and a separately stipulated dimensionless ideal weighted graph. No measured hertz, physical extra spacetime dimensions, particles, new universal theorem or independent human peer review are claimed.
**License:** MIT source code and CC BY 4.0 scientific preprint.
