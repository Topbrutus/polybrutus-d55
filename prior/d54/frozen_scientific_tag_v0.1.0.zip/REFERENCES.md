# Polybrutus D54 - cited project publications (not independent external peer review)

[1] St-Pierre, Gabriel (2026). *Polybrutus 53D: Exact 58-Point Euclidean Metric and Forty-Sevenfold Ideal Graph Mode*. Zenodo DOI [10.5281/zenodo.24430556](https://doi.org/10.5281/zenodo.24430556). **Direct frozen scientific parent**. GitHub [Polybrutus D53 v0.1.0](https://github.com/Topbrutus/polybrutus-d53/tree/v0.1.0) peeled commit \`4bd7435e63ecf58be4ce7940a61e1d6a37d29203\`.

[2] St-Pierre, Gabriel (2026). *Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model*. Zenodo DOI [10.5281/zenodo.24407952](https://doi.org/10.5281/zenodo.24407952). **Historical project reference, not D54 direct parent.**

[3] St-Pierre, Gabriel (2026). Polybrutus D53 original complete frozen scientific source tag v0.1.0, https://github.com/Topbrutus/polybrutus-d53/tree/v0.1.0; complete original ZIP preserved unchanged in D54 \`prior/d53\`, SHA256 \`872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698\`.

Zenodo metadata must include nine current \`fifty-four\` and \`forty-eightfold\` keywords, structured parent \`related_identifiers.isDerivedFrom\` D53 DOI 10.5281/zenodo.24430556, and two distinct textual \`references\` D53/D7.
