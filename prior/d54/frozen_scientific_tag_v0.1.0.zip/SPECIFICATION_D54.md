# Polybrutus D54 - exact 59-point labelled Euclidean squared-distance metric

**Only direct immutable parent:** Topbrutus/polybrutus-d53@v0.1.0, peeled scientific Git tag commit 4bd7435e63ecf58be4ce7940a61e1d6a37d29203, published DOI 10.5281/zenodo.24430556; entire original source ZIP SHA256 872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698, original certificate SHA256 b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47.

## Conservative orthogonal unit extension

Zero-embed the 58 norm-one parent points p_i as q_i=(p_i,0), and append one new orthogonal unit vector q_59. All C(58,2)=1653 predecessor labelled squared distances are exactly conserved. Every 58 new squared distances is 2R²; all 59 points yield C(59,2)=1711 unordered labelled pairs.

The exact rational Gram G is block-orthogonal: seven canonical norm-one points rank 3; centered regular five-point unit simplex of rank 4 with mutual dot products -1/4; and **47** independent perpendicular unit axes. Thus G=XXᵀ is PSD of exact rank **3+4+47=54**, and has unit diagonal.

Set D_ij=2-2G_ij, i≠j, D_ii=0. Let H=I-11ᵀ/59. The centered Euclidean Gram B=-(HDH)/2=HGH is PSD with **exact rank 54**. An inherited antipodal canonical pair puts the origin in the affine hull, proving minimal affine Euclidean realization dimension 54 of this specific synthetic metric, using 55 storage coordinates.

At R=1, k=4d²/R² counts: 4:6, 7:2, 8:1680, 9:3, 10:10, 12:6, 13:2, 16:2, total 1711. Squared-distance sum: **13735/4**.

## Separate freely specified ideal weighted graph

For scalar unit masses and stipulated positive complete-graph weights w_ij=1/d_ij², the new vertex connects to all 58 predecessors with weight 1/2. Its Laplacian block is L54=[[L53+I58/2,-1_58/2],[-1_58ᵀ/2,29]].

Characteristic-polynomial recurrence: chi59(z)=z(z-59/2)chi58(z-1/2)/(z-1/2). Closed model form with initial f6(z)=chiP7(z)/z:
chi59(z)=z(z-59/2)^48(z-29)^4*f6(z-26).

Exact rational eigenspace ranks confirm **59/2 multiplicity 48** and **29 multiplicity 4**. These dimensionless graph eigenvalues are not observed physical frequencies.

**Bibliography:** parent D53 DOI 10.5281/zenodo.24430556; historical D7 DOI 10.5281/zenodo.24407952.
