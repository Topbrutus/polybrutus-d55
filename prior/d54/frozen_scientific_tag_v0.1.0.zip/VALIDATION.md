# Polybrutus D54 verification and falsification gate

1. Authenticate only the frozen D53 v0.1.0 source commit 4bd7435e63ecf58be4ce7940a61e1d6a37d29203, DOI 10.5281/zenodo.24430556, complete original source ZIP SHA256 872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698 and original certificate SHA256 b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47. Verify ZIP CRC and original certificate bytes in both independent programs.
2. Recompute 59 unit points and all 1711 exact labelled squared-distance pairs. All 1653 predecessor labels must match; 58 new distances squared 2R²; rational Gram PSD and centered affine rank 54.
3. Independently verify labelled pair table by fractions.Fraction without importing primary Gram, centered rank and dimensionless chosen ideal Laplacian eigenvalues 59/2 x48, 29 x4.
4. Reject corrupt pair, duplicate point, tilted nonperpendicular point, histogram-preserving label permutation. Compare deterministic JSON certificate hash.
5. Require three GitHub Actions green checks: initial science main, frozen scientific tag v0.1.0, and post-Zenodo documentary main. All run two verifiers plus metadata QA.
6. Zenodo must publish original source ZIP, 2-page scientific PDF and deterministic JSON, with public matching names, byte sizes and MD5 vs local SHA256. Require nine dimension-current fifty-four/forty-eightfold keywords, structured isDerivedFrom DOI D53 and separate bibliography D53/D7.
7. Scope: synthetic Euclidean geometry and freely stipulated ideal graph, not physical detection or human peer-reviewed theorem.

    python -m pip install sympy==1.14.0
    python src/verify_d54.py
    python tests/independent_d54.py
    python src/check_zenodo_metadata.py
