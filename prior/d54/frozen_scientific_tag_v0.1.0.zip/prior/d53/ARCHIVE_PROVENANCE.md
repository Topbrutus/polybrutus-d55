# Original complete scientific Polybrutus D53 frozen source

- GitHub direct parent frozen tag: https://github.com/Topbrutus/polybrutus-d53/tree/v0.1.0
- Exact peeled scientific Git tag commit: \`4bd7435e63ecf58be4ce7940a61e1d6a37d29203\`.
- Direct parent Zenodo DOI: 10.5281/zenodo.24430556.
- Original full \`frozen_scientific_tag_v0.1.0.zip\`: 3102647 bytes, 32 entries, SHA-256 \`872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698\`, CRC PASS.
- Original parent \`results/certificate_d53.json\`: 125556 bytes, SHA-256 \`b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47\`.
- All historical original frozen source ZIPs remain nested byte-identically. D47/D46 text-only provenance discrepancy remains disclosed; no edits to ancestor source bytes.
