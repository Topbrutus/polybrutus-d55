# Polybrutus 54D: Exact 59-point Euclidean metric and a forty-eightfold ideal graph mode

**Gabriel St-Pierre** - Independent researcher
**21 November 2026**
**Exact mathematical preprint / reproducible synthetic case study**
**AI disclosure:** OpenAI ChatGPT (Astra) materially assisted the two independent exact rational programs, mathematical checks, manuscript and controlled release; AI is not the scientific author.

## Abstract

We construct a labelled exact Euclidean squared-distance metric on 59 norm-one points by adding one perpendicular unit point to the original immutable Polybrutus D53 source [1]. All 1653 predecessor labelled squared distances are preserved; 58 new squared distances each equal 2R², giving 1711 unordered labelled pairs. The centered Euclidean Gram is PSD of exact rank 54, showing the minimum affine Euclidean realization dimension is 54 for this specified synthetic metric. In a separately stipulated ideal scalar-unit-mass complete weighted graph with edge weights w_ij=1/d_ij², exact Laplacian nullities give eigenvalue 59/2 with multiplicity 48 and eigenvalue 29 with multiplicity 4. Two independently implemented rational programs verify all 1711 labelled pairs, parent source provenance and exact spectral ranks. No physical resonance or spacetime dimension is claimed.

## 1. Authentic frozen parent source and conservative extension

The exclusive immediate predecessor is St-Pierre, Polybrutus D53 [1], DOI 10.5281/zenodo.24430556, GitHub Topbrutus/polybrutus-d53@v0.1.0 with exact peeled scientific commit 4bd7435e63ecf58be4ce7940a61e1d6a37d29203. We embed the complete original D53 frozen source ZIP at prior/d53/frozen_scientific_tag_v0.1.0.zip without altering a single byte (3102647 bytes, 32 entries, CRC PASS, SHA256 872af465cdae25b8b79286b8302c5ccd31fa33ee5852b5dfda61ec01ed78f698), including all earlier original source archives nested in it. The original D53 certificate is preserved unchanged at prior/d53/results/certificate_d53.json, SHA256 b9e3be40d79af5bbe0da2a932d60738c830bc722dcec173d16760dbf10ddaf47; both independent mathematical verifiers authenticate original archive, CRC, certificate and all old pair labels.

For each prior unit vector p_i, i=1,...,58, embed q_i=(p_i,0) in a larger coordinate space. Append a new perpendicular unit vector q_59. For all old pairs, ||q_i-q_j||²=||p_i-p_j||², conserving each labelled value exactly. For each of 58 new pairs, ||q_59-q_i||²=2R². The total is C(59,2)=1711=1653+58 exact unordered labelled squared distances. This is an explicitly synthetic Euclidean construction, not evidence for higher-dimensional physical spacetime.

## 2. Exact Euclidean Gram and exhaustive labelled distances

Construct the rational Gram G as a block-orthogonal sum: seven canonical norm-one points with rank 3; a centered regular five-unit-simplex with rank 4 and mutual inner products -1/4; and 47 independent orthogonal unit axes. G=XXᵀ is therefore PSD with unit diagonal and exact rank 3+4+47=54. Let D_ii=0 and D_ij=2-2G_ij. For H=I-11ᵀ/59, the centered Euclidean Gram B=-(HDH)/2=HGH is PSD with rank 54. An inherited antipodal canonical pair shows the origin belongs to the affine hull, so the minimum affine Euclidean realization dimension of this particular metric equals 54, with 55 storage coordinates.

For unit radius, histogram of k=4d²/R²: 4:6, 7:2, 8:1680, 9:3, 10:10, 12:6, 13:2, 16:2 (1711 pairs), and exact total squared-distance sum 13735/4. In particular, 1653 old pairs are compared *by their precise labels* with the authentic original D53 certificate; a matching histogram alone would not prove conservation.

## 3. Independently chosen ideal weighted graph spectrum

Take scalar masses one and stipulate weights w_ij=1/d_ij² for a complete graph. The added point joins each of the 58 old vertices by weight 1/2. The ideal Laplacian block is L54=[[L53+I58/2,-1_58/2],[-1_58ᵀ/2,29]]. Its characteristic-polynomial recurrence is chi59(z)=z(z-59/2)chi58(z-1/2)/(z-1/2). With the seven-point factor f6(z)=chiP7(z)/z, the ideal closed form is chi59(z)=z(z-59/2)^48(z-29)^4*f6(z-26).

Exact rational Laplacian eigenspace nullities yield eigenvalue 59/2 multiplicity 48, eigenvalue 29 multiplicity 4. These are dimensionless eigenmodes of a deliberately specified graph, not observed frequencies, particles, measured resonances or physical dimensions.

## 4. Independent rational verification and negative controls

Primary src/verify_d54.py constructs Gram G with rational SymPy, computes all 1711 labelled squared distances, authenticates the source parent ZIP SHA256/CRC and original D53 certificate, verifies rank 54 and exact ideal Laplacian eigenspaces. Independently, tests/independent_d54.py reconstructs the complete 1711-pair table using Python fractions.Fraction distance rules without importing primary Gram, and independently verifies 1653 parent pairs, centered Gram rank and ideal Laplacian eigenspaces. Both reproduce precisely the same deterministic JSON certificate results/certificate_d54.json and SHA256.

Four adversarial tests reject a damaged new pair, a duplicated vertex, a norm-one but nonorthogonal tilted vertex, and histogram-preserving relabelling that violates old labels; the independent implementation additionally rejects damaged labels and relabelling.

An older original D47 certificate contained an inaccurate textual D46 grandparent Git commit reference, already disclosed since D48. All original archived bytes remain untouched. D54 authenticates its real direct D53 parent independently.

## 5. Reproduction, publication contract and scientific scope

Python 3.12 and sympy==1.14.0 reproduce the exact results. Orthogonal unit-vector extension and complete-graph uniform joins are standard mathematical operations. These results demonstrate this one synthetic metric and a freely stipulated graph, not a new universal theorem, independently peer-reviewed physics or an observed natural phenomenon. No measured hertz, particles or extra physical spacetime dimensions are inferred.

Zenodo metadata must contain exactly nine current keywords including fifty-four and forty-eightfold, structured isDerivedFrom to the direct D53 parent DOI 10.5281/zenodo.24430556, and a separate two-entry bibliography for D53 [1] and historic D7 [2]. All three public ZIP/PDF/JSON originals and the metadata require public API checks after release.

## References

[1] St-Pierre, Gabriel (2026). Polybrutus 53D: Exact 58-Point Euclidean Metric and Forty-Sevenfold Ideal Graph Mode. Zenodo DOI: 10.5281/zenodo.24430556. https://doi.org/10.5281/zenodo.24430556

[2] St-Pierre, Gabriel (2026). Polybrutus 7D: An Exact Twelve-Point Orthogonal Completion, the 12-35-37 Identity, and an Oscillator Model. Zenodo DOI: 10.5281/zenodo.24407952. https://doi.org/10.5281/zenodo.24407952

[3] St-Pierre, Gabriel (2026). Complete original frozen scientific Polybrutus D53 GitHub tag v0.1.0, https://github.com/Topbrutus/polybrutus-d53/tree/v0.1.0, peeled scientific commit 4bd7435e63ecf58be4ce7940a61e1d6a37d29203. Original ZIP embedded unchanged.
