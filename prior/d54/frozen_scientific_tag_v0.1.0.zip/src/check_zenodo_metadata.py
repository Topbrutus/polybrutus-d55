#!/usr/bin/env python3
from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
c=json.loads((R/'results/certificate_d54.json').read_text(encoding='utf8'))
m=json.loads((R/'publication/zenodo_metadata_blueprint.json').read_text(encoding='utf8'))
assert c['status']=='PASS' and c['dimension']==m['scientific_dimension']==54
assert c['vertices']==m['norm_one_vertices']==59
assert c['pairs']==m['exact_labelled_squared_pairs']==1711
assert c['affine_rank']==c['centered_gram_rank']==54
assert c['eigenvalue_59_over_2_multiplicity']==m['model_eigenvalue_59_over_2_multiplicity']==48
assert c['eigenvalue_29_multiplicity']==m['model_eigenvalue_29_multiplicity']==4
assert c['parent_tag_commit']=='4bd7435e63ecf58be4ce7940a61e1d6a37d29203'
assert c['parent_doi']==m['scientific_parent_doi']=='10.5281/zenodo.24430556'
assert m['related_identifiers']==[{'identifier':'10.5281/zenodo.24430556','relation':'isDerivedFrom','resource_type':'publication-preprint','scheme':'doi'}]
assert len(m['keywords'])==9
assert 'affine Euclidean dimension fifty-four' in m['keywords']
assert 'forty-eightfold ideal eigenvalue' in m['keywords']
assert len(m['references'])==2
assert '10.5281/zenodo.24430556' in m['references'][0]
assert '10.5281/zenodo.24407952' in m['references'][1]
assert not any(x in str(m['keywords']) for x in ('fifty-three','forty-sevenfold','fifty-five','forty-ninefold'))
note=(R/'publication/POLYBRUTUS_54D_NOTE.md').read_text('utf8')
assert all(v in note for v in ('## References','10.5281/zenodo.24430556','10.5281/zenodo.24407952'))
print('D54_CURRENT_9_KEYWORDS_PARENT_STRUCTURED_RELATION_AND_SEPARATE_BIBLIOGRAPHY_PASS')
